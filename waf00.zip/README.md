# whatsapp-api
whatsapp baileys v4

# Install
- npm run start

chcek browser localhost:9000
